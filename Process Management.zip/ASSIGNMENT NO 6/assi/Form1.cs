﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace assi
{
    public partial class Form1 : Form
    {
        Process[] p;  

        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = "calc";
            p.Start();
            button3_Click(null, null);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process p = new Process();
            p.StartInfo.FileName = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            p.StartInfo.Arguments = textBox1.Text;  
            p.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ListBox listBox = List;  
            listBox.Items.Clear();  
            p = Process.GetProcesses();
            foreach (Process process in p)
            {
                listBox.Items.Add(process.ProcessName);  
            }
            listBox.Sorted = true;  
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (List.SelectedItem != null)
            {
                string selectedProcessName = List.SelectedItem.ToString();
                Process[] processesToKill = Process.GetProcessesByName(selectedProcessName);
                foreach (Process process in processesToKill)
                {
                    process.Kill();
                }

                button3_Click(null, null);
            }
            else
            {
                MessageBox.Show("Please select a process to kill.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            button3_Click(null, null);
        }

       
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void List_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
